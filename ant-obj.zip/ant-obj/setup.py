##01.09.2023
##V.O.M.


from setuptools import setup

setup(name='ant_obj',
      version='0.0.1',
      install_requires=[]
)

