
import gym
import pybullet as pb
import pybullet_envs
import pybullet_data
import numpy as np
import time
import tianshou
import torch
import tensorflow as tf
import math


import ant_obj
from gym import Env

from gym import spaces
from gym.spaces import Box, Discrete, Dict
from gym.spaces import utils
from tensorflow import keras


if __name__ == '__main__':

    env = gym.make("AntObj-v0")
    env.render(mode="human")

    input_shape = utils.flatdim(env.observation_space)
    num_actions = utils.flatdim(env.action_space)
    env.observation_space = utils.flatten(env.observation_space, np.ndarray(shape=(1,14)))

    state = env.reset()

    done = False
    count = 0
    steps = 0
    #loading trained model
    policy_network = tf.keras.models.load_model('keras')

    try:
        
        while not done:
            steps+=1
            action_mean = policy_network.predict(np.array([state]))[0]
            #print(action_mean)
            #action_std = tf.exp(log_std).numpy()
            action_std = policy_network.predict(np.array([state]))
            action_std = np.clip(action_std, 1e-3, np.inf)
            action = np.random.normal(action_mean, action_std)
                
            action = np.clip(action, env.action_space.low, env.action_space.high)

            next_state, reward, done, info = env.step(action)
            env.render()
            
            count+=1
            
            state = next_state
            #pb.resetDebugVisualizerCamera(cameraDistance=3, cameraYaw=0, cameraPitch=-40, cameraTargetPosition = 2)

            obs, rewards, done, info = env.step(action)
            pb.stepSimulation()

            print(info)
            time.sleep(.01)

            
    finally:
        env.close()

