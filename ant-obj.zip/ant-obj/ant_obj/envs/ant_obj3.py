#16.10.2023
# Reinforce method for the Ant env


import gym
import pybullet as pb
import pybullet_envs
import pybullet_data
import numpy as np
import time
import tianshou
import torch
import tensorflow as tf
import math


import ant_obj
from gym import Env

from gym import spaces
from gym.spaces import Box, Discrete, Dict
from gym.spaces import utils
from tensorflow import keras


if __name__ == '__main__':
    
    env = gym.make("AntObj-v0")

    env.render(mode="rgb_array")

    input_shape = utils.flatdim(env.observation_space)
    num_actions = utils.flatdim(env.action_space)
    env.observation_space = utils.flatten(env.observation_space, np.ndarray(shape=(1,14)))

    ## Policy network
    ## tanh activation scales the output to be beetween -1 1 

    policy_network = tf.keras.models.Sequential([
        tf.keras.layers.Dense(32, activation='linear', input_shape=(input_shape,)),
        tf.keras.layers.Dense(32, activation='linear'),
        tf.keras.layers.Dense(num_actions, activation='tanh')
        ])

    optimizer = tf.keras.optimizers.Adam(learning_rate=0.001)
    loss_fn = tf.keras.losses.SparseCategoricalCrossentropy()
    log_std = tf.Variable(initial_value=0.5 * np.ones(num_actions), dtype=tf.float32, trainable=True)

    
    ##Training loop
    
    ##lists to store episode rewards and lengths
    episode_rewards = []
    episode_lengths = []

    num_episodes = 1000
    print('Number of episodes {}!'.format(num_episodes))

    discount_factor = 0.99

    for episode in range(num_episodes):

        state = env.reset()
        episode_reward = 0
        episode_length = 0

        states = []
        actions = []
        rewards = []


        while True:

            #print(policy_network.predict(np.array([state])))

            action_mean = policy_network.predict(np.array([state]))[0]
            #print(action_mean)
            action_std = tf.exp(log_std).numpy()
            #action_std = policy_network.predict(np.array([state]))
            action_std = np.clip(action_std, 1e-5, np.inf)
            #print(action_std, action_mean)

            
            ## distribution is created out from the probabilities
            ## before having an action the distribution has to be created


            action = np.random.normal(action_mean, action_std)
            
            #print("action",action)
            action = np.clip(action, env.action_space.low, env.action_space.high)

            next_state, reward, done, _ = env.step(action)

            

            states.append(state)
            actions.append(action)
            rewards.append(reward)

            state = next_state
            episode_reward += reward
            episode_length += 1


            if done==True:
                print('Episode {} done!'.format(episode))
                break


        discounted_rewards = np.zeros_like(rewards)
        running_total = 0

    for i in reversed(range(len(rewards))):
        running_total = running_total * discount_factor + rewards[i]
        discounted_rewards[i] = running_total

    ##normalised discounted rewards
    #print(discounted_rewards)
    discounted_rewards = discounted_rewards - np.mean(discounted_rewards)
    discounted_rewards = discounted_rewards/np.std(discounted_rewards)

    states = tf.convert_to_tensor(states, dtype=tf.float32)
    actions = tf.convert_to_tensor(actions, dtype=tf.float32)
    discounted_rewards = tf.convert_to_tensor(discounted_rewards, dtype=tf.float32)


    ##evaluation of the actions taken
    with tf.GradientTape() as tape:
        #print(policy_network(states))

        pred_means = policy_network(states)
        pred_stds = policy_network(states)


        log_probs = -0.5 * ((actions - pred_means)**2/(pred_stds ** 2 + 1e-8) + 2 * tf.math.log(pred_stds) + np.log(2 * np.pi))
        #print("log",log_probs)
        #print(discounted_rewards)
        discounted_rewards = tf.expand_dims(discounted_rewards, 1)
        loss = -tf.reduce_sum(log_probs * discounted_rewards)


    grads = tape.gradient(loss, policy_network.trainable_variables)
    optimizer.apply_gradients(zip(grads, policy_network.trainable_variables))

    episode_rewards.append(episode_reward)
    episode_lengths.append(episode_length)


    policy_network.save('k1000linear/')

