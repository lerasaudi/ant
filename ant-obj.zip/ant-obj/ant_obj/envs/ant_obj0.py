    #27.09.2023
#08.10.2023
#17.10.2023

import gym
import pybullet as pb
import pybullet_envs
import pybullet_data
import numpy as np
import time
import math

import ant_obj

from gym import error, spaces, utils

from gym import Env
from gym.spaces import Box, Discrete, Dict
from gym.spaces import utils

from gym.wrappers import RescaleAction


class AntObjEnv(gym.Env):
    metadata = {'render.modes': ['human', 'rgb_array'], 'render_fps': 4}

    
    def __init__(self, render_mode=None):
        super(AntObjEnv, self).__init__()
        self.state = self.init_state()
        self.step_count = 0

        assert render_mode is None or render_mode in self.metadata["render_modes"]
        self.render_mode = render_mode

        # Observation space is defined as a dictionary space to make it more comfortable
        # Disctionary space then is flattened for the visual representation of the BOX spaces
        # For the Training process and NN the flattened obs space has to be vectorised
        #Observation space
        self.observation_space = spaces.Dict({\
            'joint_hip_angles': spaces.Box(low=float('-inf'), high=float('inf'), shape=(4,), dtype=np.float32),\
            'joint_ankle_angles': spaces.Box(low=float('-inf'), high=float('inf'), shape=(4,), dtype=np.float32),\
            'base_position': spaces.Box(low=float('-inf'), high=float('inf'), shape=(3,), dtype=np.float32),\
            'object_position':spaces.Box(low=float('-inf'), high=float('inf'), shape=(3,), dtype=np.float32)})
        self.observation_space = utils.flatten_space(self.observation_space)

        # Action space
        self.action_space = spaces.Box(low=-1, high=1, shape=(8,), dtype=np.float32)

    def init_state(self):
        
        pb.connect(pb.GUI) ##Use pb.DIRECT for the Colab
        pb.resetSimulation()
        pb.setAdditionalSearchPath(pybullet_data.getDataPath())
        pb.setGravity(0,0,-9.8)
        pb.setRealTimeSimulation(0)
        pb.resetDebugVisualizerCamera(cameraDistance=5, cameraYaw=0, cameraPitch=-40, cameraTargetPosition = [0,0,0])


        pb.loadURDF("plane.urdf", [0, 0, 0], [0, 0, 0, 1])
        self.objid = pb.loadURDF("sphere2red.urdf", [-5,5,5], [0, 0, 0, 1])
        self.robotid = pb.loadMJCF("ant.xml")
        self.target1id = pb.loadURDF("tray.urdf", [10,10, 0], [0, 0, 0, 1])
        #self.robotid_1 = pb.loadMJCF("ant.xml")
        
        return self._get_obs()
    
    def _get_obs(self):

        joint_hip_id = [1, 6, 11, 16]
        joint_ankle_id = [3, 8, 13, 18]
        
        base_pos, base_orient  = pb.getBasePositionAndOrientation(int(self.robotid[0]))

        j_hip_1 = pb.getJointState(int(self.robotid[0]), 1)[0]
        j_hip_6 = pb.getJointState(int(self.robotid[0]), 6)[0]
        j_hip_11 = pb.getJointState(int(self.robotid[0]), 11)[0]
        j_hip_16 = pb.getJointState(int(self.robotid[0]), 16)[0]

        j_ankle_3 = pb.getJointState(int(self.robotid[0]), 3)[0]
        j_ankle_8 = pb.getJointState(int(self.robotid[0]), 8)[0]
        j_ankle_13 = pb.getJointState(int(self.robotid[0]), 13)[0]
        j_ankle_18 = pb.getJointState(int(self.robotid[0]), 18)[0]

        jv_hip_1 = pb.getJointState(int(self.robotid[0]), 1)[1]
        jv_hip_6 = pb.getJointState(int(self.robotid[0]), 6)[1]
        jv_hip_11 = pb.getJointState(int(self.robotid[0]), 11)[1]
        jv_hip_16 = pb.getJointState(int(self.robotid[0]), 16)[1]

        jv_ankle_3 = pb.getJointState(int(self.robotid[0]), 3)[1]
        jv_ankle_8 = pb.getJointState(int(self.robotid[0]), 8)[1]
        jv_ankle_13 = pb.getJointState(int(self.robotid[0]), 13)[1]
        jv_ankle_18 = pb.getJointState(int(self.robotid[0]), 18)[1]

        obj_pos, obj_orient  = pb.getBasePositionAndOrientation((self.objid))
        obj_vel, obj_avel = pb.getBaseVelocity((self.objid))
        
        base_vel, base_avel = pb.getBaseVelocity(int(self.robotid[0]))
        obj_vel, obj_avel = pb.getBaseVelocity((self.objid))

        obs = {\
            'joint_hip_angles': [j_hip_1, j_hip_6, j_hip_11, j_hip_16],\
            'joint_ankle_angles': [j_ankle_3, j_ankle_8, j_ankle_13, j_ankle_18],\
            'base_position': [base_pos[0], base_pos[1], base_pos[2]],\
            'object_position': [obj_pos[0], obj_pos[1], obj_pos[2]]}

        obs = np.array([j_hip_1, j_hip_6, j_hip_11, j_hip_16,\
                        j_ankle_3, j_ankle_8, j_ankle_13, j_ankle_18,\
                        base_pos[0], base_pos[1], base_pos[2],\
                        obj_pos[0], obj_pos[1], obj_pos[2]])
                         # a copy of the array collapsed into one dimension  

        #print(j_hip_1, j_hip_6, j_hip_11, j_hip_16, j_ankle_3,j_ankle_8, j_ankle_13, j_ankle_18)
        return obs

    ## reward function  
    def reward_function(self, distance_c, distance_n, distance_g_c, distance_g_n):
        
        if (distance_n < distance_c and distance_g_n < distance_g_c):
            return 10
        elif (distance_n < distance_c):
            return 15
        else:
            return -1

    ##Location of the object - ball   
    def _agentobj_loc(self, obs):
        obj_pos = [obs[11], obs[12], obs[13]]
        obj_pos = np.array(obj_pos)
        return obj_pos
    ##location of the target
    def _target_loc(self):         
        target_pos, target_orient  = pb.getBasePositionAndOrientation((self.target1id))
        target_pos = np.array(target_pos)
        return target_pos
    
    def _robot_loc(self, obs):
        base_pos = [obs[8], obs[9], obs[10]]
        base_pos = np.array(base_pos)
        return base_pos

    def _get_info(self, obs):
        agent_loc = np.array(self._agentobj_loc(obs))
        target_loc = np.array(self._target_loc())
        
        return {"distance": np.linalg.norm( agent_loc - target_loc , ord=1)}

    def _take_action(self, action_r):

        ## denormalized action
        action_r = action_r
        jl_h = -0.6981317400932312  
        ju_h = 0.698131740093231

        range_hip = ju_h-jl_h

        jlower_ankle = 0.5235987901687622
        jupper_ankle = 1.7453292608261108

        range_ankle = jupper_ankle-jlower_ankle

    
        j_h_1 = (float(action_r[0]) + 1)*0.5*range_hip+jl_h
        j_h_6 = (action_r[1] + 1)*0.5*range_hip+jl_h
        j_h_11 = (action_r[2] + 1)*0.5*range_hip+jl_h
        j_h_16 = (action_r[3] + 1)*0.5*range_hip+jl_h


        j_a_3 = (action_r[4] + 1)*0.5*range_ankle+jlower_ankle
        j_a_8 = (action_r[5] + 1)*0.5*range_ankle+jlower_ankle
        j_a_13 = (action_r[6] + 1)*0.5*range_ankle+jlower_ankle
        j_a_18 = (action_r[7] + 1)*0.5*range_ankle+jlower_ankle
        """
        
        j_h_1 = (float(action_r[0]) + 1)*0.5*range_hip+jl_h
        j_h_6 = 0
        j_h_11 = (action_r[2] + 1)*0.5*range_hip+jl_h
        j_h_16 = 0


        j_a_3 = 0
        j_a_8 = (action_r[5] + 1)*0.5*range_ankle+jlower_ankle
        j_a_13 = 0
        j_a_18 = (action_r[7] + 1)*0.5*range_ankle+jlower_ankle
        """

        #print(j_h_1, j_h_6, j_h_11, j_h_16, j_a_3, j_a_13, j_a_8, j_a_18)
        
        pb.setJointMotorControlArray(2, [1, 3, 6, 8, 11, 13, 16, 18] , pb.POSITION_CONTROL, targetPositions = [j_h_1, j_a_3, j_h_6, j_a_8, j_h_11, j_a_13, j_h_16, j_a_18])

        pb.stepSimulation()


    def reset(self):
        pb.disconnect()
        self.step_count = 0
        self.state = self.init_state()
        return self.state


        
    def step(self, action_r):

        current_state = self._get_obs()
        distance_c = (np.linalg.norm(self._robot_loc(current_state) - self._agentobj_loc(current_state)),'fro')
        distance_g_c = (np.linalg.norm(self._agentobj_loc(current_state) - self._target_loc()), 'fro')

        
        self._take_action(action_r)
        self.step_count += 1
        next_state = self._get_obs()
        distance_n = (np.linalg.norm( self._robot_loc(next_state) - self._agentobj_loc(next_state)), 'fro')
        distance_g_n = (np.linalg.norm(self._agentobj_loc(next_state) - self._target_loc()), 'fro')
        self.state = next_state
        info = self._get_info(next_state)

        done = False
        reward = self.reward_function(distance_c, distance_n, distance_g_c, distance_g_n)
        
        if (self.step_count >= 5000) :
            self.reset()
            reward = self.reward_function(distance_c, distance_n, distance_g_c, distance_g_n)
            done = True
            print(self.state)

            return next_state, reward, done, info

        #self.render()
        else:
            return next_state, reward, done, info


    def render(self, mode=None):
        pass
        #print(f'Step: {self.step_count}')


    def close(self):
        pb.disconnect()
  

