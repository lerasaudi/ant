#27.09.2023
#08.09.2023

import gym
import pybullet as pb
import pybullet_envs
import pybullet_data
import numpy as np
import time
import math

import ant_obj

from gym import error, spaces, utils
from gym.utils import seeding

from gym import Env
from gym import spaces
from gym.spaces import Box, Discrete, Dict

from gym.wrappers import RescaleAction




"""
## action wrapper
class DiscreteActions(gym.ActionWrapper):
    
    def __init__(self, env, disc_to_cont):
        super().__init__(env)
        self.disc_to_cont = disc_to_cont
        self._action_space = Discrete(len(disc_to_cont))

    ##the method action is overwritten
    def action(self, act):
        return self.disc_to_cont[act]


    if __name__ == "__main__":
            env = gym.make("AntObj")
            wrapped_env = DiscreteActions(env, [np.array([-1,1]), np.array([-1,1]),  np.array([-1,1]), np.array([-1,1]),
                                                np.array([-1,1]), np.array([-1,1]),  np.array([-1,1]), np.array([-1,1])])

"""
"""
##Initialization of the GUI
pb.connect(pb.GUI) ##Use pb.DIRECT for the Colab
pb.resetSimulation()
pb.setAdditionalSearchPath(pybullet_data.getDataPath())
pb.setGravity(0,0,-9.8)
pb.setRealTimeSimulation(0)



## Load the required models for the enviroment Ant, Object - sphere, Plane
pb.loadURDF("plane.urdf", [0, 0, 0], [0, 0, 0, 1])
objid = pb.loadURDF("sphere2red.urdf", [5,5,5], [0, 0, 0, 1])
robotid = pb.loadMJCF("ant.xml")


pb.getNumJoints(int(robotid[0]))

for i in range(pb.getNumJoints(int(robotid[0]))):
    print(pb.getJointInfo(int(robotid[0]), i))

"""
"""
##Joints indexes for the movement
jointid = [1, 3, 6, 8, 11, 13, 16, 18]

for i in range(len(jointid)):
    jtype = pb.getJointInfo(int(robotid[0]), jointid[i])[2]
    jlower = pb.getJointInfo(int(robotid[0]), jointid[i])[8]
    jupper = pb.getJointInfo(int(robotid[0]), jointid[i])[9]
    print(jtype, jlower, jupper)
"""
"""
jointid_hip = 1
jointid_ankle = 3

jlower_hip = pb.getJointInfo(int(robotid[0]), jointid_hip)[8]
jupper_hip = pb.getJointInfo(int(robotid[0]), jointid_hip)[9]

jlower_ankle = pb.getJointInfo(int(robotid[0]), jointid_ankle)[8]
jupper_ankle = pb.getJointInfo(int(robotid[0]), jointid_ankle)[9]

print(jlower_hip, jupper_hip, jlower_ankle, jupper_ankle)
## Target location for the object to be moved
larget_loc = [10, 10, 0]



for step in range(5000):

    robot_pos , _ = pb.getBasePositionAndOrientation(int(robotid[0]))
    pb.resetDebugVisualizerCamera(cameraDistance=3, cameraYaw=0, cameraPitch=-40, cameraTargetPosition = int(robotid[0]))

    joint_one_targ = np.random.uniform(jlower_hip, jupper_hip)
    joint_three_targ = np.random.uniform(jlower_ankle, jupper_ankle)

    pb.setJointMotorControlArray(int(robotid[0]), [1, 3], pb.POSITION_CONTROL, targetPositions = [joint_one_targ, joint_three_targ])

    
    pb.stepSimulation()

    time.sleep(.01)

"""

class AntObjEnv(gym.Env):
    metadata = {'render.modes': ['human', 'rgb_array'], 'render_fps': 4} 

    def __init__(self, render_mode=None):
        self.state = self.init_state()
        self.step_count = 0

        assert render_mode is None or render_mode in self.metadata["render_modes"]
        self.render_mode = render_mode
        
        ##self.action_space = Discrete(7)


    def init_state(self):
        
        pb.connect(pb.GUI) ##Use pb.DIRECT for the Colab
        pb.resetSimulation()
        pb.setAdditionalSearchPath(pybullet_data.getDataPath())
        pb.setGravity(0,0,-9.8)
        pb.setRealTimeSimulation(0)

        pb.loadURDF("plane.urdf", [0, 0, 0], [0, 0, 0, 1])
        self.objid = pb.loadURDF("sphere2red.urdf", [5,5,5], [0, 0, 0, 1])
        self.robotid = pb.loadMJCF("ant.xml")

        ## Observations

        joint_hip_id = [1, 6, 11, 16]
        joint_ankle_id = [3, 8, 13, 18]
        
        base_pos, base_orient  = pb.getBasePositionAndOrientation(int(self.robotid[0]))

        j_hip_1 = pb.getJointState(int(self.robotid[0]), 1)[0]
        j_hip_6 = pb.getJointState(int(self.robotid[0]), 6)[0]
        j_hip_11 = pb.getJointState(int(self.robotid[0]), 11)[0]
        j_hip_16 = pb.getJointState(int(self.robotid[0]), 16)[0]

        j_ankle_3 = pb.getJointState(int(self.robotid[0]), 3)[0]
        j_ankle_8 = pb.getJointState(int(self.robotid[0]), 8)[0]
        j_ankle_13 = pb.getJointState(int(self.robotid[0]), 13)[0]
        j_ankle_18 = pb.getJointState(int(self.robotid[0]), 18)[0]

        jv_hip_1 = pb.getJointState(int(self.robotid[0]), 1)[1]
        jv_hip_6 = pb.getJointState(int(self.robotid[0]), 6)[1]
        jv_hip_11 = pb.getJointState(int(self.robotid[0]), 11)[1]
        jv_hip_16 = pb.getJointState(int(self.robotid[0]), 16)[1]

        jv_ankle_3 = pb.getJointState(int(self.robotid[0]), 3)[1]
        jv_ankle_8 = pb.getJointState(int(self.robotid[0]), 8)[1]
        jv_ankle_13 = pb.getJointState(int(self.robotid[0]), 13)[1]
        jv_ankle_18 = pb.getJointState(int(self.robotid[0]), 18)[1]

        obj_pos, obj_orient  = pb.getBasePositionAndOrientation((self.objid))
        
        base_vel, base_avel = pb.getBaseVelocity(int(self.robotid[0]))
        obj_vel, obj_avel = pb.getBaseVelocity((self.objid))


        obs = np.array([base_pos[0], base_pos[1], base_pos[2],\
                        base_orient[0], base_orient[1], base_orient[2],\
                        j_hip_1, j_hip_6, j_hip_11, j_hip_16,\
                        j_ankle_3, j_ankle_8, j_ankle_13, j_ankle_18,\
                        obj_pos[0], obj_pos[1], obj_pos[2],\
                        obj_orient[0], obj_orient[1], obj_orient[2],\
                        base_vel[0], base_vel[1], base_vel[2],\
                        base_avel[0], base_avel[1],base_avel[2],\
                        jv_hip_1, jv_hip_6, jv_hip_11, jv_hip_16,\
                        jv_ankle_3, jv_ankle_8, jv_ankle_13, jv_ankle_18,\
                        obj_vel[0], obj_vel[1],obj_vel[2],\
                        obj_avel[0],obj_avel[1],obj_avel[2]]).flatten()  # a copy of the array collapsed into one dimension             

        #print(len(obs))
        #print(obs)
        
        return obs


    def reset(self):
        pb.disconnect()
        self.state = self.init_state()
        self.step_count = 0

        
    def step(self, action):
        self.step_count += 1
        
        pb.setJointMotorControlArray(int(self.robotid[0]), [1, 3, 6, 8, 11, 13, 16, 18], pb.POSITION_CONTROL, [action])
        pb.stepSimulation()

        

        base_pos, base_orient  = pb.getBasePositionAndOrientation(int(self.robotid[0]))

        j_hip_1 = pb.getJointState(int(self.robotid[0]), 1)[0]
        j_hip_6 = pb.getJointState(int(self.robotid[0]), 6)[0]
        j_hip_11 = pb.getJointState(int(self.robotid[0]), 11)[0]
        j_hip_16 = pb.getJointState(int(self.robotid[0]), 16)[0]

        j_ankle_3 = pb.getJointState(int(self.robotid[0]), 3)[0]
        j_ankle_8 = pb.getJointState(int(self.robotid[0]), 8)[0]
        j_ankle_13 = pb.getJointState(int(self.robotid[0]), 13)[0]
        j_ankle_18 = pb.getJointState(int(self.robotid[0]), 18)[0]

        jv_hip_1 = pb.getJointState(int(self.robotid[0]), 1)[1]
        jv_hip_6 = pb.getJointState(int(self.robotid[0]), 6)[1]
        jv_hip_11 = pb.getJointState(int(self.robotid[0]), 11)[1]
        jv_hip_16 = pb.getJointState(int(self.robotid[0]), 16)[1]

        jv_ankle_3 = pb.getJointState(int(self.robotid[0]), 3)[1]
        jv_ankle_8 = pb.getJointState(int(self.robotid[0]), 8)[1]
        jv_ankle_13 = pb.getJointState(int(self.robotid[0]), 13)[1]
        jv_ankle_18 = pb.getJointState(int(self.robotid[0]), 18)[1]

        obj_pos, obj_orient  = pb.getBasePositionAndOrientation((self.objid))
        
        base_vel, base_avel = pb.getBaseVelocity(int(self.robotid[0]))
        obj_vel, obj_avel = pb.getBaseVelocity((self.objid))

        ##simple action enviroment learning
        if (self.step_count >= 50) :
            self.reset()
            base_pos, base_orient  = pb.getBasePositionAndOrientation(int(self.robotid[0]))

            j_hip_1 = pb.getJointState(int(self.robotid[0]), 1)[0]
            j_hip_6 = pb.getJointState(int(self.robotid[0]), 6)[0]
            j_hip_11 = pb.getJointState(int(self.robotid[0]), 11)[0]
            j_hip_16 = pb.getJointState(int(self.robotid[0]), 16)[0]

            j_ankle_3 = pb.getJointState(int(self.robotid[0]), 3)[0]
            j_ankle_8 = pb.getJointState(int(self.robotid[0]), 8)[0]
            j_ankle_13 = pb.getJointState(int(self.robotid[0]), 13)[0]
            j_ankle_18 = pb.getJointState(int(self.robotid[0]), 18)[0]

            jv_hip_1 = pb.getJointState(int(self.robotid[0]), 1)[1]
            jv_hip_6 = pb.getJointState(int(self.robotid[0]), 6)[1]
            jv_hip_11 = pb.getJointState(int(self.robotid[0]), 11)[1]
            jv_hip_16 = pb.getJointState(int(self.robotid[0]), 16)[1]

            jv_ankle_3 = pb.getJointState(int(self.robotid[0]), 3)[1]
            jv_ankle_8 = pb.getJointState(int(self.robotid[0]), 8)[1]
            jv_ankle_13 = pb.getJointState(int(self.robotid[0]), 13)[1]
            jv_ankle_18 = pb.getJointState(int(self.robotid[0]), 18)[1]

            obj_pos, obj_orient  = pb.getBasePositionAndOrientation((self.objid))
            
            base_vel, base_avel = pb.getBaseVelocity(int(self.robotid[0]))
            obj_vel, obj_avel = pb.getBaseVelocity((self.objid))


            obs = np.array([base_pos[0], base_pos[1], base_pos[2],\
                            base_orient[0], base_orient[1], base_orient[2],\
                            j_hip_1, j_hip_6, j_hip_11, j_hip_16,\
                            j_ankle_3, j_ankle_8, j_ankle_13, j_ankle_18,\
                            obj_pos[0], obj_pos[1], obj_pos[2],\
                            obj_orient[0], obj_orient[1], obj_orient[2],\
                            base_vel[0], base_vel[1], base_vel[2],\
                            base_avel[0], base_avel[1],base_avel[2],\
                            jv_hip_1, jv_hip_6, jv_hip_11, jv_hip_16,\
                            jv_ankle_3, jv_ankle_8, jv_ankle_13, jv_ankle_18,\
                            obj_vel[0], obj_vel[1],obj_vel[2],\
                            obj_avel[0],obj_avel[1],obj_avel[2]]).flatten()  # a copy of the array collapsed into one dimension             



            self.state = obs
            reward = -1
            done = True

            return reward, done

            obs = np.array([base_pos[0], base_pos[1], base_pos[2],\
                            base_orient[0], base_orient[1], base_orient[2],\
                            j_hip_1, j_hip_6, j_hip_11, j_hip_16,\
                            j_ankle_3, j_ankle_8, j_ankle_13, j_ankle_18,\
                            obj_pos[0], obj_pos[1], obj_pos[2],\
                            obj_orient[0], obj_orient[1], obj_orient[2],\
                            base_vel[0], base_vel[1], base_vel[2],\
                            base_avel[0], base_avel[1],base_avel[2],\
                            jv_hip_1, jv_hip_6, jv_hip_11, jv_hip_16,\
                            jv_ankle_3, jv_ankle_8, jv_ankle_13, jv_ankle_18,\
                            obj_vel[0], obj_vel[1],obj_vel[2],\
                            obj_avel[0],obj_avel[1],obj_avel[2]]).flatten()  # a copy of the array collapsed into one dimension             


        self.state = obs

        done = False
        reward = -1 # arbitrary reward

        return reward, done


 #   def render(self, mode='human'):
 #      self.renderer.render(pb.)


    def close(self):
        pb.disconnect()





"""  

    for step in range(5000):

        robot_pos , _ = pb.getBasePositionAndOrientation(int(robotid[0]))
        pb.resetDebugVisualizerCamera(cameraDistance=3, cameraYaw=0, cameraPitch=-40, cameraTargetPosition = int(robotid[0]))

        joint_one_targ = np.random.uniform(jlower_hip, jupper_hip)
        joint_three_targ = np.random.uniform(jlower_ankle, jupper_ankle)

        pb.setJointMotorControlArray(int(robotid[0]), [1, 3], pb.POSITION_CONTROL, targetPositions = [joint_one_targ, joint_three_targ])

        
        pb.stepSimulation()

        time.sleep(.01)

                                                   
"""
                                                   
"""


        ...
"""
