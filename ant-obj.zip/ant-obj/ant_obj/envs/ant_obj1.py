
import gym
import pybullet as pb
import pybullet_envs
import pybullet_data
import numpy as np
import time
import math

import ant_obj

from gym import error, spaces, utils

from gym import Env
from gym import spaces
from gym.spaces import Box, Discrete, Dict
from gym.spaces import utils

from gym.wrappers import RescaleAction

"""
if __name__ == '__main__':

    env = gym.make("AntObj-v0")
    # env.render(mode="human")

    input_shape = utils.flatdim(env.observation_space)
    num_actions = utils.flatdim(env.action_space)
    env.observation_space = utils.flatten(env.observation_space, np.ndarray(shape=(1,14)))

    state = env.reset()

    done = False
    count=0
    done=False
    steps = 0
    #loading trained model
    policy_network = tf.keras.models.load_model('keras')


    
    try:
        
        while not done:

        steps+=1
    
        # Get the action probabilities from the policy network
        action_probs = policy_network.predict(np.array([state]))[0]

        # Choose an action based on the action probabilities
        action = np.random.choice(num_actions, p=action_probs)

        next_state, reward, done, info = env.step(action) # take a step in the environment
        image = env.render() # render the environment to the screen
   
        #convert image to pygame surface object
        image = Image.fromarray(image,'RGB')
        mode,size,data = image.mode,image.size,image.tobytes()
        image = pygame.image.fromstring(data, size, mode)

   
        print_summary('Step {}'.format(steps),(10,10),15)
        pygame.display.update()
        clock.tick(100)
        count+=1
        pygame.time.delay(10)
        state = next_state 

            
    finally:
        env.close()
"""

if __name__ == '__main__':

    env = gym.make("AntObj-v0")
    # env.render(mode="human")
    
    try:
        for step in range(50000): ## has to be rewritten

            action_min = -1.0
            action_max = 1.0

            a_1 = np.random.uniform(action_min, action_max)
            a_2 = np.random.uniform(action_min, action_max)
            a_3 = np.random.uniform(action_min, action_max)
            a_4 = np.random.uniform(action_min, action_max)

            a_5 = np.random.uniform(action_min, action_max)
            a_6 = np.random.uniform(action_min, action_max)
            a_7 = np.random.uniform(action_min, action_max)
            a_8 = np.random.uniform(action_min, action_max)

            action_r = [a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8]

            pb.resetDebugVisualizerCamera(cameraDistance=3, cameraYaw=0, cameraPitch=-40, cameraTargetPosition = 2)

            obs, rewards, done, info = env.step(action_r)
            pb.stepSimulation()

            print(info)
            time.sleep(.01)

    finally:
        env.close()

