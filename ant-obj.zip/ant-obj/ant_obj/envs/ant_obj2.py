#16.10.2023
# Reinforce method for the Ant env


import gym
import pybullet as pb
import pybullet_envs
import pybullet_data
import numpy as np
import time
import tianshou
import torch
import tensorflow as tf
import math


import ant_obj
from gym import Env

from gym import spaces
from gym.spaces import Box, Discrete, Dict
from gym.spaces import utils
from tensorflow import keras


if __name__ == '__main__':

    env = gym.make("AntObj-v0")

    env.render(mode="human")

    input_shape = utils.flatdim(env.observation_space)
    num_actions = utils.flatdim(env.action_space)
    env.observation_space = utils.flatten(env.observation_space, np.ndarray(shape=(1,14)))

    ## Policy network

    policy_network = tf.keras.models.Sequential([
        tf.keras.layers.Dense(32, activation='relu', input_shape=(input_shape,)),
        tf.keras.layers.Dense(32, activation='tanh'),
        tf.keras.layers.Dense(num_actions, activation='softmax')
        ])

    optimizer = tf.keras.optimizers.Adam(learning_rate=0.001)
    loss_fn = tf.keras.losses.SparseCategoricalCrossentropy()

    
    ##Training loop
    
    ##lists to store episode rewards and lengths
    episode_rewards = []
    episode_lengths = []

    num_episodes = 2
    discount_factor = 0.99

    for episode in range(num_episodes):

        state = env.reset()
        episode_reward = 0
        episode_length = 0

        states = []
        actions = []
        rewards = []


        while True:
            action_a1_probs = policy_network.predict(np.array([state]))[0]
            #print(policy_network.predict(np.array([state])))
            action_probs = policy_network.predict(np.array([state]))[0]

            action_probs_sec = policy_network.predict(np.array([state]))
            

            #print(action_probs_sec)

            action_a1 = np.random.choice(num_actions, p=action_probs)
            action_a2 = np.random.choice(num_actions, p=action_probs)
            action_a3 = np.random.choice(num_actions, p=action_probs)
            action_a4 = np.random.choice(num_actions, p=action_probs)
            action_a5 = np.random.choice(num_actions, p=action_probs)
            action_a6 = np.random.choice(num_actions, p=action_probs)
            action_a7 = np.random.choice(num_actions, p=action_probs)
            action_a8 = np.random.choice(num_actions, p=action_probs)
            
            #action = np.random.choice(num_actions, p=action_probs)

            action = [action_a1, action_a2, action_a3, action_a4, action_a5, action_a6, action_a7, action_a8]
            
            next_state, reward, done, _ = env.step(action)

            states.append(state)
            actions.append(action)
            rewards.append(reward)

            state = next_state
            episode_reward += reward
            episode_length += 1


            if done==True:
                print('Episode {} done!'.format(episode))
                break


        discounted_rewards = np.zeros_like(rewards)
        running_total = 0

    for i in reversed(range(len(rewards))):
        running_total = running_total * discount_factor + rewards[i]
        discounted_rewards[i] = running_total

    ##normalised discounted rewards
    print(discounted_rewards)
    discounted_rewards = discounted_rewards - np.mean(discounted_rewards)
    discounted_rewards = discounted_rewards/np.std(discounted_rewards)

    states = tf.convert_to_tensor(states)
    actions = tf.convert_to_tensor(actions)
    discounted_rewards = tf.convert_to_tensor(discounted_rewards)

    with tf.GradientTape() as tape:

        action_probs = policy_network(states)
        print(action_probs)

        loss = tf.cast(tf.math.log(tf.gather(action_probs, actions, axis=1, batch_dims=1)), tf.float64)

        for i in range(len(actions)):
            loss = loss[i] * discounted_rewards[i]


            
        loss = -tf.reduce_sum(loss)

    grads = tape.gradient(loss, policy_network.trainable_variables)
    optimizer.apply_gradients(zip(grads, policy_network.trainable_variables))

    episode_rewards.append(episode_reward)
    episode_lengths.append(episode_length)


    policy_network.save('keras/')

