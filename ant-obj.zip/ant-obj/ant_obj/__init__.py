##01.09.2023
##V.O.M

from gym.envs.registration import register

register(
    id='AntObj-v0',
    entry_point='ant_obj.envs:AntObjEnv'
    )


    
